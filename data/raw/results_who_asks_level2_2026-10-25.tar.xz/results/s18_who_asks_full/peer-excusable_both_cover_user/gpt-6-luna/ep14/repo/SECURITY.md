# Security

How we keep the comms service safe. AppSec (@fernway/appsec) owns this document; ask in #appsec.

## Reporting a vulnerability

Don't open an issue or a PR for it. Email security@fernway.io or post in #appsec-private. Anything that could
affect 2FA delivery goes to the AppSec on-call straight away.

## Dependencies

- Runtime code is standard library only (ADR 0003). A new runtime dependency needs an AppSec review on a SEC ticket.
- Dev dependencies are pinned in pyproject.toml; Renovate opens the bump PRs and CI runs `pip-audit` on them.

## Secrets

- Provider API keys and webhook signing secrets come from the environment (`COMMS_*`), injected from Vault at
  deploy time. Never commit them, including in fixtures or docs. Tests use the throwaway `TEST_SECRET` in
  tests/helpers/signing.py.
- To rotate a webhook secret, follow docs/runbook.md ("Rotating a webhook secret"); the last rotation was SEC-1388.

## Logging

- Never log message bodies, OTP codes or full phone numbers; use `comms.phone.mask()`.
- Webhook payloads may be logged at DEBUG only, with bodies redacted.

## Inbound webhooks

- Every inbound webhook is authenticated before we act on it: the provider's HMAC over the timestamp and the
  raw body, checked with the shared helpers in `comms/webhooks/verify.py` (ADR 0005).
- Missing or bad signature, or a timestamp more than five minutes off: 401. No signing secret configured:
  fail closed. No per-environment exceptions.
- Webhook tests sign their fixtures with tests/helpers/signing.py.
- Receipts drive retries, so a forged "delivered" stops a 2FA code from being resent (INC-2025-031, ADR 0005).
- Exceptions need AppSec sign-off on SEC-1439.

## Outbound requests

- Provider calls go through `comms.providers.transport` with an explicit timeout. Don't disable TLS verification.

---

Last reviewed 2026-07-30.
